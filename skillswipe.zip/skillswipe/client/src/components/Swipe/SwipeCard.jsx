import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  Avatar,
  IconButton,
  CardMedia,
  Snackbar,
  Alert
} from '@mui/material';
import { motion, useAnimation } from 'framer-motion';
import { Close as CloseIcon, Favorite as FavoriteIcon } from '@mui/icons-material';
import { School, Share } from '@mui/icons-material';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';

const SwipeCard = ({ profile, onSwipe, onMatch }) => {
  const controls = useAnimation();
  const { token } = useAuth();
  const [notification, setNotification] = React.useState({ open: false, message: '', severity: 'success' });

  const handleSwipe = async (liked) => {
    try {
      if (!token || !profile?._id) {
        console.error('Missing token or profile ID');
        setNotification({
          open: true,
          message: 'Authentication or profile data missing',
          severity: 'error'
        });
        return;
      }

      console.log('Sending like request:', {
        likedUserId: profile._id,
        liked
      });

      const response = await axios.post(
        'http://localhost:5000/api/users/like',
        {
          likedUserId: profile._id,
          liked
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      console.log('Like response:', response.data);

      if (response.data.isMatch) {
        setNotification({
          open: true,
          message: `You matched with ${profile.username || profile.name}! 🎉`,
          severity: 'success'
        });
        if (onMatch) onMatch(profile);
      } else if (liked) {
        setNotification({
          open: true,
          message: `You liked ${profile.username || profile.name}!`,
          severity: 'info'
        });
      }

      onSwipe(liked);
    } catch (error) {
      console.error('Error handling swipe:', error);
      const errorMessage = error.response?.data?.message || 'Failed to process your action';
      console.error('Error details:', errorMessage);
      setNotification({
        open: true,
        message: errorMessage,
        severity: 'error'
      });
    }
  };

  const handleDragEnd = (event, info) => {
    const swipeThreshold = 100;
    const swipeDirection = info.offset.x > swipeThreshold ? 'right' : 
                          info.offset.x < -swipeThreshold ? 'left' : null;
    
    if (swipeDirection) {
      handleSwipe(swipeDirection === 'right');
    } else {
      controls.start({ x: 0 });
    }
  };

  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };

  if (!profile) {
    return (
      <Card sx={{ 
        minHeight: 500,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
        borderRadius: 3,
        boxShadow: 3
      }}>
        <Typography variant="h6" color="text.secondary">
          No more profiles to show
        </Typography>
      </Card>
    );
  }

  // Separate skills into teaching and learning
  const skillsToShare = profile.skills?.filter(skill => skill.willingToTeach) || [];
  const skillsToLearn = profile.skills?.filter(skill => skill.wantToLearn) || [];

  return (
    <>
      <motion.div
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        onDragEnd={handleDragEnd}
        animate={controls}
        style={{ width: '100%', maxWidth: 500, margin: '0 auto' }}
      >
        <Card sx={{ 
          minHeight: 500,
          position: 'relative',
          backgroundColor: '#fff',
          borderRadius: 3,
          boxShadow: 3
        }}>
          {profile.profilePicture && (
            <CardMedia
              component="img"
              height="300"
              image={`http://localhost:5000/api/users/profile-picture/${profile.profilePicture}`}
              alt={profile.name || profile.username}
              sx={{ 
                objectFit: 'cover',
                borderRadius: '50%',
                width: '300px',
                height: '300px',
                margin: '20px auto',
                border: '3px solid #1976d2',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
              }}
            />
          )}
          
          <CardContent>
            <Typography variant="h5" gutterBottom>
              {profile.name || profile.username}
            </Typography>
            
            {profile.bio && (
              <Typography variant="body2" color="text.secondary" paragraph>
                {profile.bio}
              </Typography>
            )}

            {skillsToShare.length > 0 && (
              <Box sx={{ mb: 2 }}>
                <Typography variant="subtitle2" color="primary" gutterBottom>
                  <Share sx={{ mr: 1, verticalAlign: 'middle' }} />
                  Skills to Share:
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {skillsToShare.map((skill, index) => (
                    <Chip
                      key={index}
                      label={`${skill.name} (${skill.level})`}
                      size="small"
                      color="primary"
                      variant="outlined"
                    />
                  ))}
                </Box>
              </Box>
            )}

            {skillsToLearn.length > 0 && (
              <Box>
                <Typography variant="subtitle2" color="secondary" gutterBottom>
                  <School sx={{ mr: 1, verticalAlign: 'middle' }} />
                  Skills to Learn:
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {skillsToLearn.map((skill, index) => (
                    <Chip
                      key={index}
                      label={`${skill.name} (${skill.level})`}
                      size="small"
                      color="secondary"
                      variant="outlined"
                    />
                  ))}
                </Box>
              </Box>
            )}
          </CardContent>

          <Box sx={{ 
            position: 'absolute',
            bottom: 16,
            left: 0,
            right: 0,
            display: 'flex',
            justifyContent: 'center',
            gap: 2
          }}>
            <IconButton
              onClick={() => handleSwipe(false)}
              sx={{
                backgroundColor: 'error.light',
                color: 'white',
                '&:hover': { backgroundColor: 'error.main' }
              }}
            >
              <CloseIcon />
            </IconButton>
            <IconButton
              onClick={() => handleSwipe(true)}
              sx={{
                backgroundColor: 'success.light',
                color: 'white',
                '&:hover': { backgroundColor: 'success.main' }
              }}
            >
              <FavoriteIcon />
            </IconButton>
          </Box>
        </Card>
      </motion.div>

      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.severity}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default SwipeCard;
