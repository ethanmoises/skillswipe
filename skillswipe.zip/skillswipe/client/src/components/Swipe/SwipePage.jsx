import React, { useState, useEffect } from 'react';
import { Box, Typography, CircularProgress, Button, IconButton } from '@mui/material';
import { NavigateBefore, NavigateNext } from '@mui/icons-material';
import SwipeCard from './SwipeCard';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const SwipePage = () => {
  const [profiles, setProfiles] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    loadProfiles();
  }, []);

  const loadProfiles = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/login');
        return;
      }

      console.log('Fetching profiles...');
      const response = await axios.get('http://localhost:5000/api/users/all-profiles', {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      console.log('Received profiles:', response.data.length);
      setProfiles(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error loading profiles:', error);
      setError(error.response?.data?.message || 'Failed to load profiles');
      setLoading(false);
    }
  };

  const handleSwipe = async (liked) => {
    if (!profiles[currentIndex]) return;

    const swipedProfile = profiles[currentIndex];
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post('http://localhost:5000/api/users/like', {
        likedUserId: swipedProfile._id,
        liked
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (response.data.isMatch) {
        const goToChat = window.confirm('It\'s a match! Would you like to start chatting?');
        if (goToChat) {
          navigate('/matches');
          return;
        }
      }

      handleNext();
    } catch (error) {
      console.error('Error handling swipe:', error);
      setError(error.response?.data?.message || 'Failed to process swipe');
    }
  };

  const handleNext = () => {
    if (currentIndex < profiles.length - 1) {
      setCurrentIndex(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const handleViewMatches = () => {
    navigate('/matches');
  };

  if (loading) {
    return (
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh' 
      }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ 
        display: 'flex', 
        flexDirection: 'column',
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh',
        gap: 2
      }}>
        <Typography variant="h6" color="error">
          {error}
        </Typography>
        <Button 
          variant="contained" 
          onClick={loadProfiles}
        >
          Retry Loading Profiles
        </Button>
      </Box>
    );
  }

  if (profiles.length === 0) {
    return (
      <Box sx={{ 
        display: 'flex', 
        flexDirection: 'column',
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh',
        gap: 2
      }}>
        <Typography variant="h5">
          No profiles available right now
        </Typography>
        <Button 
          variant="contained" 
          color="primary"
          onClick={loadProfiles}
        >
          Refresh Profiles
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ 
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      p: 2,
      minHeight: '100vh',
      backgroundColor: '#f5f5f5'
    }}>
      <Box sx={{ 
        width: '100%', 
        maxWidth: 600, 
        display: 'flex', 
        justifyContent: 'space-between',
        mb: 2 
      }}>
        <Button 
          variant="outlined" 
          color="primary"
          onClick={() => loadProfiles()}
        >
          Refresh Profiles
        </Button>
        <Button 
          variant="outlined" 
          color="primary"
          onClick={handleViewMatches}
        >
          View Matches
        </Button>
      </Box>

      <Box sx={{ 
        display: 'flex', 
        alignItems: 'center', 
        width: '100%', 
        maxWidth: 600,
        justifyContent: 'space-between',
        mb: 2 
      }}>
        <IconButton 
          onClick={handlePrevious}
          disabled={currentIndex === 0}
          sx={{ backgroundColor: 'white', '&:hover': { backgroundColor: '#f0f0f0' } }}
        >
          <NavigateBefore />
        </IconButton>

        <Typography variant="body2" color="text.secondary">
          Profile {currentIndex + 1} of {profiles.length}
        </Typography>

        <IconButton 
          onClick={handleNext}
          disabled={currentIndex === profiles.length - 1}
          sx={{ backgroundColor: 'white', '&:hover': { backgroundColor: '#f0f0f0' } }}
        >
          <NavigateNext />
        </IconButton>
      </Box>

      {profiles[currentIndex] && (
        <SwipeCard
          profile={profiles[currentIndex]}
          onSwipe={handleSwipe}
        />
      )}
    </Box>
  );
};

export default SwipePage;
