const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const User = require('../models/User');
const auth = require('../middleware/auth');

// Configure multer for handling file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

const upload = multer({ storage: storage });

// Upload profile picture
router.post('/upload-profile-picture', auth, upload.single('profilePicture'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    const user = await User.findById(req.user.id);
    user.profilePicture = req.file.filename;
    await user.save();

    res.json({ 
      message: 'Profile picture uploaded successfully',
      filename: req.file.filename 
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get profile picture
router.get('/profile-picture/:filename', (req, res) => {
  const filename = req.params.filename;
  res.sendFile(process.cwd() + '/uploads/' + filename);
});

// Register new user
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Check if user exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Create new user
    user = new User({
      username,
      email,
      password,
      likes: [],
      dislikes: [],
      matches: []
    });

    // Hash password
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(password, salt);

    await user.save();

    // Create token
    const payload = {
      id: user.id
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '24h' });

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email
      }
    });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Login user
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Validate password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Create token
    const payload = {
      id: user.id
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '24h' });

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get user profile
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    res.json(user);
  } catch (error) {
    console.error('Profile error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update user profile
router.post('/profile', auth, async (req, res) => {
  try {
    const { bio, location, skills } = req.body;
    const user = await User.findById(req.user.id);

    if (bio) user.bio = bio;
    if (location) user.location = location;
    if (skills) user.skills = skills;

    await user.save();
    res.json(user);
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all potential matches
router.get('/all-profiles', auth, async (req, res) => {
  try {
    console.log('Fetching profiles for user:', req.user.id);
    
    // Get all users except the current user
    const potentialMatches = await User.find({
      _id: { $ne: req.user.id }
    })
    .select('-password')
    .lean();

    console.log('Found profiles:', potentialMatches.length);

    // Shuffle the array randomly
    const shuffledMatches = potentialMatches.sort(() => Math.random() - 0.5);
    
    res.json(shuffledMatches);
  } catch (error) {
    console.error('Error getting potential matches:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Like or pass a user
router.post('/like', auth, async (req, res) => {
  try {
    const { likedUserId, liked } = req.body;

    if (!likedUserId) {
      return res.status(400).json({ message: 'No user ID provided' });
    }

    const [currentUser, likedUser] = await Promise.all([
      User.findById(req.user.id),
      User.findById(likedUserId)
    ]);

    if (!currentUser || !likedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Prevent self-liking
    if (currentUser.id === likedUser.id) {
      return res.status(400).json({ message: 'Cannot like yourself' });
    }

    let isMatch = false;

    if (liked) {
      // Add to likes if not already there
      if (!currentUser.likes.includes(likedUserId)) {
        currentUser.likes.push(likedUserId);
      }
      
      // Check if it's a match
      isMatch = likedUser.likes.includes(currentUser.id);
      
      if (isMatch) {
        // Add to matches if not already there
        if (!currentUser.matches.includes(likedUserId)) {
          currentUser.matches.push(likedUserId);
        }
        if (!likedUser.matches.includes(currentUser.id)) {
          likedUser.matches.push(currentUser.id);
          await likedUser.save();
        }
      }
    } else {
      // Add to dislikes if not already there
      if (!currentUser.dislikes.includes(likedUserId)) {
        currentUser.dislikes.push(likedUserId);
      }
    }
    
    await currentUser.save();
    res.json({ 
      isMatch,
      message: liked ? (isMatch ? 'Match created!' : 'Like recorded') : 'Pass recorded'
    });
  } catch (error) {
    console.error('Error in like/pass:', error);
    res.status(500).json({ message: 'Failed to process like/pass action' });
  }
});

// Get user's matches
router.get('/matches', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
      .populate('matches', '-password');
    res.json(user.matches);
  } catch (error) {
    console.error('Error getting matches:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
